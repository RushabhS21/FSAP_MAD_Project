// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
//
// import 'Cartfile.dart';
//
// class TabTry extends StatefulWidget {
//   const TabTry({Key? key}) : super(key: key);
//
//   @override
//   State<TabTry> createState() => _TabTryState();
// }
//
// class _TabTryState extends State<TabTry> {
//   List store=[];
//   String _scanBarcode = 'Unknown 10';
//   String temp='';
//   List<String> item=[];
//   void initState() {
//     super.initState();
//   }
//   Future<void> startBarcodeScanStream() async {
//     FlutterBarcodeScanner.getBarcodeStreamReceiver(
//         '#ff6666', 'Cancel', true, ScanMode.BARCODE)!
//         .listen((barcode) => print(barcode));
//   }
//
//   Future<void> scanQR() async {
//
//     String barcodeScanRes;
//     try {
//       barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
//           '#ff6666', 'Cancel', true, ScanMode.QR);
//       print(barcodeScanRes);
//     } on PlatformException {
//       barcodeScanRes = 'Failed to get platform version.';
//     }
// //barcode scanner flutter ant
//     setState(() {
//       item.add(barcodeScanRes);
//       String test=item.last;
//       int last=int.parse(test);
//       print(last);
//       // store[1]=barcodeScanRes;
//       // temp=store[1];
//     });
//   }
//
//   Future<void> scanBarcodeNormal() async {
//     String barcodeScanRes;
//     try {
//       barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
//           '#ff6666', 'Cancel', true, ScanMode.BARCODE);
//       print(barcodeScanRes);
//     } on PlatformException {
//       barcodeScanRes = 'Failed to get platform version.';
//     }
//
//     if (!mounted) return;
//     setState(() {
//       _scanBarcode = barcodeScanRes;
//       // store[1]=barcodeScanRes;
//     });
//   }
//
//
//   Widget build(BuildContext context) {
//     var test=_scanBarcode.split(' ');
//     int b=int.parse(test[1]);
//     return DefaultTabController(
//       length: 3,
//       initialIndex: 1,
//       child: Scaffold(
//             appBar: AppBar(
//               title: Text('FSAP',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
//               centerTitle: true,
//               backgroundColor: Colors.deepPurple,
//               bottom: TabBar(
//                 isScrollable: true,
//                 indicatorColor: Colors.indigoAccent,
//
//                 tabs: [
//                   Tab(
//                     icon: Icon(Icons.add_a_photo),
//                   ),
//                   Tab(
//                     icon: Icon(Icons.add_a_photo),
//                   ),
//                   Tab(
//                     child: Text("BarcodeScanner"),
//                   )
//                 ],
//               ),
//             ),
//         body: TabBarView(
//           children: [
//             Center(
//                 child: Flex(
//                 direction: Axis.vertical,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                 IconButton(
//                 icon: Icon(Icons.shopping_cart_rounded,size: 40,),
//                 onPressed: () => scanQR(),
//                 ),
//                 ElevatedButton(onPressed: (){
//                 setState(() {
//                 item.add(temp);
//                 Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CartPage(items: item, temps: temp,count:)));
//                 });
//                 // Navigator.of(context).push(MaterialPageRoute(builder: (context)=>TrailPage(scanBarcode: _scanBarcode)));
//                 }, child: Text("Go to cart"))
//                 ],
//                 ),
//                 ),
//             // Center(
//             //   child: Icon(Icons.connected_tv_sharp),
//             // ),
//             Center(
//               child: Text("Add a Photo"),
//             ),
//             Center(
//               child: Text("BarcodeScanner"),
//             )
//
//           ],
//         ),
//       ),
//     );
//   }
// }
