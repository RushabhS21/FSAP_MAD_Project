import 'package:dynamiclist/main.dart';
import 'package:flutter/material.dart';

class CartPage extends StatefulWidget {
  CartPage({required this.items,required this.temps});
  int count=0;
  List<String> items=[];
  String temps;
  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // List<String> storeditem=[];
  int total = 90;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                shrinkWrap: true,
                children: widget.items.map((e) {
                  return Card(
                    child: ListTile(
                      title: Text(e),
                        trailing: Container(
                          width: 30,
                          child: Row(
                            children: [
                             Expanded(child: IconButton(onPressed: () {
                                setState(() {
                                  widget.items.remove(widget.temps);
                              });
                            },
                                icon: Icon(Icons.delete)))
                          ],
                        ),
                      ),
                    ),


                  );
                })?.toList() ?? [],
              ),

            ),
            Text(''),
            FloatingActionButton(onPressed: () {
              Navigator.of(context).pop(
                  MaterialPageRoute(builder: (context) => MyApp()));
            })
          ],

        ),
      ),
    );
  }
}


    //     // appBar: AppBar(
    //     //   title:Text("Cart") ,
    //     body: ListView.builder(
    //       itemCount: widget.items.length,
    //       shrinkWrap: true,
    //       itemBuilder: (context, index) {
    //         return Card(
    //               child: ListTile(
    //                 title: Text("${widget.items[index]}"),
    //                 subtitle: Text("${total}"),
    //                 trailing: Container(
    //                     child: Row(
    //                         children: [
    //                           Expanded(
    //                             child: IconButton(onPressed: () {
    //                               setState(() {
    //                                 widget.items.remove(widget.temp);
    //                               });
    //                             },
    //                                 icon: Icon(Icons.delete)),
    //                           )
    //                         ]
    //                     ),
    //                   ),
    //               ),
    //         );
    //       }
    //   // ?.toList()
    //     ),
    //   );
    // }
    // }


    //
    //   body: Center(
    //   child:Column(
    //     children: [
    //
    //       //
    //       Expanded(
    //         child: ListView(
    //           shrinkWrap: true,
    //           children: widget.items.map((e){
    //             return Card(
    //               child: ListTile(
    //                 title:Text(e),
    //                 trailing: Container(
    //                   width: 30,
    //                   child: Row(
    //                     children: [
    //                       Expanded(child: IconButton(onPressed: (){
    //                         setState(() {
    //                           widget.items.remove(widget.temps);
    //                         });
    //
    //                       },
    //                           icon: Icon(Icons.delete)))
    //                     ],
    //                   ),
    //                 ),
    //               ),
    //
    //
    //             );
    //           })?.toList()  ??[],
    //         ),
    //
    //       ),
    //       Text(''),
    //       FloatingActionButton(onPressed: (){
    //         Navigator.of(context).pop(MaterialPageRoute(builder: (context)=>MyApp()));
    //       })
    //     ],
    //
    //   ),
    // ),
    // );

