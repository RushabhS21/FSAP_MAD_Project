package com.example.dynamiclist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
